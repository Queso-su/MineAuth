package com.quesox.mineauth.mixin;

import com.quesox.mineauth.MineAuth;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Set;
import net.minecraft.network.packet.s2c.play.PositionFlag;

@Mixin(ServerPlayerEntity.class)
public class ServerPlayerEntityMixin {

    @Unique
    private Vec3d mineAuth$initialPosition = null;

    @Unique
    private int mineAuth$messageCooldown = 0;

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        ServerPlayerEntity player = (ServerPlayerEntity) (Object) this;

        if (!MineAuth.isPlayerLoggedIn(player.getUuid())) {
            // 记录初始位置
            if (mineAuth$initialPosition == null) {
                mineAuth$initialPosition = player.getEntityPos();
            }

            // 检查玩家是否移动了
            double distance = player.squaredDistanceTo(mineAuth$initialPosition);
            if (distance > 0.1) { // 如果移动超过0.3格
                // 传送回初始位置，使用空的标志集合，不重置相机
                player.teleport(
                        (ServerWorld) player.getEntityWorld(),  // 转换为ServerWorld
                        mineAuth$initialPosition.x,
                        mineAuth$initialPosition.y,
                        mineAuth$initialPosition.z,
                        Set.of(),  // 空的PositionFlag集合
                        player.getYaw(),
                        player.getPitch(),
                        false  // 不重置相机
                );

                // 设置速度为0
                player.setVelocity(Vec3d.ZERO);

                // 发送消息（有冷却时间避免刷屏）
                if (mineAuth$messageCooldown <= 0) {
                    player.sendMessage(net.minecraft.text.Text.literal("§c请先登录后再移动！"), true);
                    mineAuth$messageCooldown = 40; // 2秒冷却（20 ticks/秒）
                }
            }

            // 减少消息冷却
            if (mineAuth$messageCooldown > 0) {
                mineAuth$messageCooldown--;
            }

            // 确保玩家不会下落
            if (!player.isOnGround() && player.getVelocity().y < 0) {
                player.setVelocity(player.getVelocity().x, 0, player.getVelocity().z);
                player.fallDistance = 0; // 防止摔落伤害
            }

            // 防止玩家跳跃
            player.setVelocity(player.getVelocity().x, Math.max(player.getVelocity().y, 0), player.getVelocity().z);
        } else {
            // 登录后重置
            mineAuth$initialPosition = null;
            mineAuth$messageCooldown = 0;
        }
    }

    // 阻止跳跃
    @Inject(method = "jump", at = @At("HEAD"), cancellable = true)
    private void onJump(CallbackInfo ci) {
        ServerPlayerEntity player = (ServerPlayerEntity) (Object) this;

        if (!MineAuth.isPlayerLoggedIn(player.getUuid())) {
            ci.cancel();
        }
    }
}
package com.quesox.mineauth.mixin;

import com.quesox.mineauth.MineAuth;
import net.minecraft.network.packet.c2s.play.ChatMessageC2SPacket;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerPlayNetworkHandler.class)
public abstract class ChatMessageMixin {

    @Shadow public ServerPlayerEntity player;

    @Inject(method = "onChatMessage", at = @At("HEAD"), cancellable = true)
    private void onChatMessage(ChatMessageC2SPacket packet, CallbackInfo ci) {
        // 如果玩家未登录
        if (!MineAuth.isPlayerLoggedIn(player.getUuid())) {
            String message = packet.chatMessage().trim();

            // 检查是否是允许的命令
            if (message.startsWith("/")) {
                // 是命令
                boolean allowed = false;
                String[] allowedCommands = {"login", "register", "reg"};
                for (String cmd : allowedCommands) {
                    if (message.toLowerCase().startsWith("/" + cmd + " ") || message.equalsIgnoreCase("/" + cmd)) {
                        allowed = true;
                        break;
                    }
                }
                if (!allowed) {
                    player.sendMessage(Text.literal("§c请先登录后再执行命令！"), true);
                    ci.cancel();
                }
            } else {
                // 不是命令，是普通聊天消息
                player.sendMessage(Text.literal("§c请先登录后再发送聊天消息！"), true);
                ci.cancel();
            }
        }
    }
}
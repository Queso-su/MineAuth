// ServerPlayerRestrictionsMixin.java (新建)
package com.quesox.mineauth.mixin;

import com.quesox.mineauth.MineAuth;
import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Set;

import static net.minecraft.entity.damage.DamageTypes.OUT_OF_WORLD;

@Mixin(ServerPlayerEntity.class)
public class ServerPlayerRestrictionsMixin {

    @Unique
    private Vec3d mineAuth$initialPosition = null;

    @Unique
    private int mineAuth$messageCooldown = 0;

    // ==================== 移动限制 ====================
    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        ServerPlayerEntity player = (ServerPlayerEntity) (Object) this;

        if (!MineAuth.isPlayerLoggedIn(player.getUuid())) {
            // 记录初始位置
            if (mineAuth$initialPosition == null) {
                mineAuth$initialPosition = player.getEntityPos();
            }

            // 检查玩家是否移动了
            double distance = player.squaredDistanceTo(mineAuth$initialPosition);
            if (distance > 0.1) { // 如果移动超过0.3格
                // 传送回初始位置，使用空的标志集合，不重置相机
                player.teleport(
                        (ServerWorld) player.getEntityWorld(),
                        mineAuth$initialPosition.x,
                        mineAuth$initialPosition.y,
                        mineAuth$initialPosition.z,
                        Set.of(),
                        player.getYaw(),
                        player.getPitch(),
                        false
                );

                // 设置速度为0
                player.setVelocity(Vec3d.ZERO);

                // 发送消息（有冷却时间避免刷屏）
                if (mineAuth$messageCooldown <= 0) {
                    player.sendMessage(net.minecraft.text.Text.literal("§c请先登录后再移动！"), true);
                    mineAuth$messageCooldown = 40;
                }
            }

            // 减少消息冷却
            if (mineAuth$messageCooldown > 0) {
                mineAuth$messageCooldown--;
            }

            // 确保玩家不会下落
            if (!player.isOnGround() && player.getVelocity().y < 0) {
                player.setVelocity(player.getVelocity().x, 0, player.getVelocity().z);
                player.fallDistance = 0;
            }

            // 防止玩家跳跃
            player.setVelocity(player.getVelocity().x, Math.max(player.getVelocity().y, 0), player.getVelocity().z);
        } else {
            // 登录后重置
            mineAuth$initialPosition = null;
            mineAuth$messageCooldown = 0;
        }
    }

    @Inject(method = "jump", at = @At("HEAD"), cancellable = true)
    private void onJump(CallbackInfo ci) {
        ServerPlayerEntity player = (ServerPlayerEntity) (Object) this;

        if (!MineAuth.isPlayerLoggedIn(player.getUuid())) {
            ci.cancel();
        }
    }

    // ==================== 伤害保护 ====================
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void onDamage(ServerWorld world, DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        ServerPlayerEntity player = (ServerPlayerEntity) (Object) this;

        if (!MineAuth.isPlayerLoggedIn(player.getUuid())) {
            // 如果是虚空伤害或来自管理员的伤害，允许伤害（防止卡bug）
            if (source.isOf(OUT_OF_WORLD) || source.isSourceCreativePlayer()) {
                return;
            }

            // 阻止所有其他伤害
            cir.setReturnValue(false);
            cir.cancel();

            // 如果伤害来源是实体，发送消息
            if (source.getAttacker() != null) {
                player.sendMessage(net.minecraft.text.Text.literal("§c请先登录！登录前你不会受到伤害。"), true);
            }
        }
    }

    // ==================== 实体交互 ====================
    @Inject(method = "interact", at = @At("HEAD"), cancellable = true)
    private void onInteract(Entity entity, Hand hand, CallbackInfoReturnable<ActionResult> cir) {
        ServerPlayerEntity player = (ServerPlayerEntity) (Object) this;

        if (!MineAuth.isPlayerLoggedIn(player.getUuid())) {
            player.sendMessage(net.minecraft.text.Text.literal("§c请先登录后再与实体交互！"), true);
            cir.setReturnValue(ActionResult.FAIL);
            cir.cancel();
        }
    }

    @Inject(method = "attack", at = @At("HEAD"), cancellable = true)
    private void onAttack(Entity target, CallbackInfo ci) {
        ServerPlayerEntity player = (ServerPlayerEntity) (Object) this;

        if (!MineAuth.isPlayerLoggedIn(player.getUuid())) {
            player.sendMessage(net.minecraft.text.Text.literal("§c请先登录后再攻击实体！"), true);
            ci.cancel();
        }
    }
}
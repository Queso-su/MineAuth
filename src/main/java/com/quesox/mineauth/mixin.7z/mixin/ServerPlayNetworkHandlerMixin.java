package com.quesox.mineauth.mixin;

import com.quesox.mineauth.MineAuth;
import net.minecraft.network.packet.c2s.play.CommandExecutionC2SPacket;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerPlayNetworkHandler.class)
public abstract class ServerPlayNetworkHandlerMixin {

    @Shadow public ServerPlayerEntity player;

    @Inject(method = "onCommandExecution", at = @At("HEAD"), cancellable = true)
    private void onCommandExecution(CommandExecutionC2SPacket packet, CallbackInfo ci) {
        // 如果玩家未登录
        if (!MineAuth.isPlayerLoggedIn(player.getUuid())) {
            String command = packet.command().trim();
            boolean allowed = false;
            String[] allowedCommands = {"login", "register", "reg"};
            for (String cmd : allowedCommands) {
                if (command.toLowerCase().startsWith(cmd + " ") || command.equalsIgnoreCase(cmd)) {
                    allowed = true;
                    break;
                }
            }
            if (!allowed) {
                player.sendMessage(Text.literal("§c请先登录后再执行命令！"), true);
                ci.cancel();
            }
        }
    }
}